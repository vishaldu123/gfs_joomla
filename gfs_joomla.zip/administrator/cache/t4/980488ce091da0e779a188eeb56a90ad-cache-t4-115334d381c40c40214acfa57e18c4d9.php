<?php die("Access Denied"); ?>#x#a:6:{s:6:"layout";s:5957:"<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" dir="ltr">

<head>
  
  {t4post:head}

  <!--[if lt IE 9]>
    <script src="/global_joomla/gfs_joomla/media/jui/js/html5.js"></script>
  <![endif]-->
  <meta name="viewport"  content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=yes"/>
  <style  type="text/css">
    @-webkit-viewport   { width: device-width; }
    @-moz-viewport      { width: device-width; }
    @-ms-viewport       { width: device-width; }
    @-o-viewport        { width: device-width; }
    @viewport           { width: device-width; }
  </style>
  <meta name="HandheldFriendly" content="true"/>
  <meta name="apple-mobile-web-app-capable" content="YES"/>
  <!-- //META FOR IOS & HANDHELD -->
  
</head>

<body class="{t4post:bodyclass}">
  
  <div class="t4-offcanvas" data-offcanvas-options='{"modifiers":"right,overlay"}' id="off-canvas-right" role="complementary" style="display:none;">
	<div class="t4-off-canvas-header">
	 		  <a href="http://localhost/global_joomla/gfs_joomla/" title="Stark.">
	  	    	  	
	    	      <span class="site-name">Stark.</span>	      	    
	  	  </a>
	  		<button type="button" class="close js-offcanvas-close" data-dismiss="modal" aria-hidden="true">×</button>
	</div>

	<div class="t4-off-canvas-body" data-effect="def">
		<jdoc:include type="modules" name="off-canvas" style="JAxhtml" />
	</div>
</div>
  <div class="t4-wrapper">
    <div class="t4-content">
      <div class="t4-content-inner">
        

<div id="t4-header" class="t4-section  t4-header  t4-sticky">
<div class="t4-section-inner container"><div class="t4-row row">
<div class="t4-col logo col col-lg-2">
<jdoc:include type="element" name="logo"<?php echo  ?> />
</div>
<div class="t4-col mainnav col">
<div class="t4-navbar">
  <jdoc:include type="element" name="megamenu" />
  <jdoc:include type="element" name="offcanvas-toggle" />
</div>

</div>
</div></div>
</div>

<div id="t4-hero" class="t4-section  t4-hero  t4-section-inview"><div class="bg-overlay bg-overlay-image">&nbsp;</div>
<div class="t4-section-inner container"><div class="t4-row row">
<div class="t4-col hero-1 col-12 col-md-6">
<jdoc:include type="modules" name="hero-1" style="raw" />
</div>
<div class="t4-col hero-2 col-sm col-md-6 d-none d-sm-none d-md-block d-lg-block d-xl-block">
<jdoc:include type="modules" name="hero-2" />
</div>
</div></div>
</div>

<div id="t4-section-1" class="t4-section  t4-section-1  t4-section-inview gutter-big  t4-palette-primary"><div class="bg-overlay bg-overlay-image">&nbsp;</div>
<div class="t4-section-inner container"><jdoc:include type="modules" name="section-1" style="T4Section" /></div>
</div>

<div id="t4-section-2" class="t4-section  t4-section-2  gutter-big t4-section-inview">
<div class="t4-section-inner container"><jdoc:include type="modules" name="section-2" style="T4Section" /></div>
</div>

<div id="t4-section-3" class="t4-section  t4-section-3  mod-right t4-section-inview"><div class="bg-overlay bg-overlay-image">&nbsp;</div>
<div class="t4-section-inner container"><jdoc:include type="modules" name="section-3" style="T4Section" /></div>
</div>

<div id="t4-section-4" class="t4-section  t4-section-4  container-lg heading-center t4-section-inview">
<div class="t4-section-inner container"><jdoc:include type="modules" name="section-4" style="T4Section" /></div>
</div>

<div id="t4-section-5" class="t4-section  t4-section-5  container-md heading-center t4-section-inview  t4-palette-transparent"><div class="bg-overlay bg-overlay-image">&nbsp;</div>
<div class="t4-section-inner container"><jdoc:include type="modules" name="section-5" style="T4Section" /></div>
</div>

<div id="t4-section-6" class="t4-section  t4-section-6  heading-left t4-section-inview">
<div class="t4-section-inner container"><jdoc:include type="modules" name="section-6" style="T4Section" /></div>
</div>

<div id="t4-section-7" class="t4-section  t4-section-7  t4-section-inview  t4-palette-gray"><div class="bg-overlay bg-overlay-image">&nbsp;</div><div class="t4-row row">
<div class="t4-col section-7 col-12 col-lg-6">
<jdoc:include type="modules" name="section-7" style="T4Section" />
</div>
<div class="t4-col section-7-spacer col-12 col-lg-6 d-none d-sm-none d-md-block d-lg-block d-xl-block hidden-md">
<jdoc:include type="modules" name="section-7-spacer" />
</div>
</div></div>

<div id="t4-section-8" class="t4-section  t4-section-8  t4-section-inview   t4-palette-primary"><div class="bg-overlay bg-overlay-image">&nbsp;</div><div class="t4-row row">
<div class="t4-col section-8-spacer col-12 col-lg-6 hidden-md">
<jdoc:include type="modules" name="section-8-spacer" />
</div>
<div class="t4-col section-8 col-12 col-lg-6">
<jdoc:include type="modules" name="section-8" style="T4Section" />
</div>
</div></div>

<div id="t4-footer" class="t4-section  t4-footer  t4-section-inview  t4-palette-dark">
<div class="t4-section-inner container"><div class="t4-row row">
<div class="t4-col footer col-sm col-md-7">
<jdoc:include type="modules" name="footer" style="raw" />
</div>
<div class="t4-col spacer col-sm hidden-md">
<jdoc:include type="modules" name="spacer" />
</div>
</div></div>
</div>

<div id="t4-footnav" class="t4-section  t4-footnav  t4-palette-dark">
<div class="t4-section-inner container"><div class="t4-row row">
<div class="t4-col logo col-sm-12 col-md-3">
<jdoc:include type="element" name="logo"<?php echo  ?> />
</div>
<div class="t4-col footnav-1 col-sm col-md-3">
<jdoc:include type="modules" name="footnav-1" style="JAxhtml" />
</div>
<div class="t4-col footnav-2 col-sm col-md-3">
<jdoc:include type="modules" name="footnav-2" style="JAxhtml" />
</div>
<div class="t4-col footnav-3 col-sm col-md-3">
<jdoc:include type="modules" name="footnav-3" style="JAxhtml" />
</div>
</div></div>
</div><a href='javascript:' id='back-to-top'><i class='fa fa-chevron-up'></i></a>
      </div>
    </div>
  </div>
  
</body>
</html>
";s:6:"assets";a:2:{s:6:"script";a:6:{i:0;s:6:"jquery";i:1;s:15:"t4.bootstrap.js";i:2;s:17:"jquery-noconflict";i:3;s:14:"jquery-migrate";i:4;s:13:"html5lightbox";i:5;s:9:"Animation";}s:5:"style";a:4:{i:0;s:13:"font.awesome5";i:1;s:13:"font.awesome4";i:2;s:13:"font.iconmoon";i:3;s:9:"Animation";}}s:8:"_scripts";a:5:{s:101:"/global_joomla/gfs_joomla/plugins/system/t4/themes/base/vendors/js-offcanvas/_js/js-offcanvas.pkgd.js";a:2:{s:4:"type";s:15:"text/javascript";s:7:"options";a:0:{}}s:100:"/global_joomla/gfs_joomla/plugins/system/t4/themes/base/vendors/bodyscrolllock/bodyScrollLock.min.js";a:2:{s:4:"type";s:15:"text/javascript";s:7:"options";a:0:{}}s:71:"/global_joomla/gfs_joomla/plugins/system/t4/themes/base/js/offcanvas.js";a:2:{s:4:"type";s:15:"text/javascript";s:7:"options";a:0:{}}s:59:"/global_joomla/gfs_joomla/templates/ja_stark/js/template.js";a:2:{s:4:"type";s:15:"text/javascript";s:7:"options";a:0:{}}s:66:"/global_joomla/gfs_joomla/plugins/system/t4/themes/base/js/base.js";a:2:{s:4:"type";s:15:"text/javascript";s:7:"options";a:1:{s:7:"version";s:4:"auto";}}}s:12:"_styleSheets";a:2:{s:98:"/global_joomla/gfs_joomla/plugins/system/t4/themes/base/vendors/js-offcanvas/_css/js-offcanvas.css";a:2:{s:4:"type";s:8:"text/css";s:7:"options";a:0:{}}s:55:"templates/ja_stark/fonts/LouisGeorgeCafe/stylesheet.css";a:2:{s:4:"type";s:8:"text/css";s:7:"options";a:0:{}}}s:6:"_links";a:2:{s:60:"/global_joomla/gfs_joomla/index.php?format=feed&amp;type=rss";a:3:{s:8:"relation";s:9:"alternate";s:7:"relType";s:3:"rel";s:7:"attribs";a:2:{s:4:"type";s:19:"application/rss+xml";s:5:"title";s:7:"RSS 2.0";}}s:61:"/global_joomla/gfs_joomla/index.php?format=feed&amp;type=atom";a:3:{s:8:"relation";s:9:"alternate";s:7:"relType";s:3:"rel";s:7:"attribs";a:2:{s:4:"type";s:20:"application/atom+xml";s:5:"title";s:8:"Atom 1.0";}}}s:5:"_file";s:67:"D:\wamp64\www\global_joomla\gfs_joomla\templates/ja_stark/index.php";}